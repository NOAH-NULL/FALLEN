def test_greeting_embed_defaults_are_enabled_and_have_placeholders():
    from pathlib import Path
    src=Path('bot/services/guild_config.py').read_text()
    assert "welcome_embed_enabled':True" in src
    assert "goodbye_embed_enabled':True" in src
    assert "welcome_embed_description" in src
    assert "goodbye_embed_description" in src

def test_greeting_worker_sends_embed_with_banner_attachment():
    from pathlib import Path
    src=Path('bot/workers/greetings.py').read_text()
    assert "discord.Embed" in src
    assert "attachment://{filename}" in src
    assert "embed=embed" in src
    assert "file=discord.File(buf,filename=filename)" in src
