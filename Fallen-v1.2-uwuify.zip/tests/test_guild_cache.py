import asyncio, pytest
from bot.services.guild_config import GuildConfigService
class Cache:
    def __init__(self): self.data={}; self.locks={}
    async def get_json(self,k): return self.data.get(k)
    async def set_json(self,k,v,ttl=0): self.data[k]=v
    async def delete(self,k): self.data.pop(k,None)
    async def publish(self,*a): pass
    async def acquire_lock(self,k,t,ttl):
        if k in self.locks: return False
        self.locks[k]=t; return True
    async def release_lock(self,k,t): self.locks.pop(k,None); return True
class Result:
    def mappings(self): return self
    def first(self): return None
class Session:
    async def __aenter__(self): return self
    async def __aexit__(self,*a): pass
    async def execute(self,*a,**k): return Result()
class DB:
    def session(self): return Session()
@pytest.mark.asyncio
async def test_concurrent_cache_misses_are_coalesced():
    c=Cache(); s=GuildConfigService(DB(),c,ttl=60)
    await asyncio.gather(*[s.get(1) for _ in range(50)])
    assert any(v['guild_id']==1 for v in c.data.values())
