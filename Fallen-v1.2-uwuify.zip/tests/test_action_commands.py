from pathlib import Path


def test_prefix_is_comma_only():
    src = Path('bot/core/config.py').read_text()
    assert "command_prefix:str=','" in src


def test_required_action_commands_exist_in_slash_surface():
    src = Path('bot/commands/fun.py').read_text()
    for name in ('hug','highfive','pat','poke','slap','bite','tickle','hold','boop','wave','punch','attack','shoot','bully','cry','dance','blush','smile','pout','shrug','sleep','fuck'):
        assert f"name='{name}'" in src


def test_required_action_commands_exist_in_prefix_surface():
    src = Path('bot/commands/text.py').read_text()
    for name in ('hug','highfive','pat','poke','slap','bite','tickle','hold','boop','wave','punch','attack','shoot','bully','cry','dance','blush','smile','pout','shrug','sleep','fuck'):
        assert f"name='{name}'" in src or f'name="{name}"' in src


def test_fuck_action_is_non_sexual():
    src = Path('bot/commands/fun.py').read_text().lower()
    assert 'non-sexual' in src


def test_every_action_has_gif_key():
    src = Path('bot/commands/fun.py').read_text()
    for name in ('hug','highfive','pat','poke','slap','bite','tickle','hold','boop','wave','kill','punch','attack','shoot','bully','cry','dance','blush','smile','pout','shrug','sleep','fuck'):
        line = next(x for x in src.splitlines() if f"'{name}':" in x)
        assert "(None," not in line
