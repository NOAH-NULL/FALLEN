from io import BytesIO
from pathlib import Path
import asyncio
import aiohttp
from PIL import Image, ImageDraw, ImageFont


class GreetingRenderer:
    """Render customizable welcome/goodbye cards over static images or GIFs.

    `background` may be a local asset path or an http(s) URL. Animated GIFs keep
    their frames/duration so a server can use a custom animated banner.
    """
    def __init__(self):
        self.http = None

    async def start(self):
        self.http = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15))

    async def close(self):
        if self.http:
            await self.http.close()
            self.http = None

    async def render(self, member, kind, background, template, count, inviter_id=None, invite_uses=0):
        avatar = await self._avatar(member.display_avatar.url)
        background_bytes = await self._background_bytes(background)
        return await asyncio.to_thread(
            self._render_sync, member, background_bytes, template, count, avatar, inviter_id, invite_uses
        )

    async def _avatar(self, url):
        async with self.http.get(url) as r:
            r.raise_for_status()
            return Image.open(BytesIO(await r.read())).convert("RGBA")

    async def _background_bytes(self, source):
        if not source:
            return None
        if str(source).startswith(("http://", "https://")):
            async with self.http.get(str(source)) as r:
                r.raise_for_status()
                return await r.read()
        path = Path(str(source))
        if not path.is_absolute():
            path = Path(__file__).resolve().parents[2] / path
        if path.exists():
            return path.read_bytes()
        return None

    @staticmethod
    def _frame(base, member, template, count, avatar, inviter_id=None, invite_uses=0):
        im = base.convert("RGBA").resize((1000, 350))
        avatar = avatar.resize((190, 190))
        mask = Image.new("L", avatar.size, 0)
        ImageDraw.Draw(mask).ellipse((0, 0, 190, 190), fill=255)
        im.paste(avatar, (405, 35), mask)
        draw = ImageDraw.Draw(im)
        font = ImageFont.load_default(size=26)
        text = template.format(
            mention=member.mention,
            name=member.display_name,
            username=member.name,
            server=member.guild.name,
            count=count,
            membercount=count,
            inviter=(f'<@{inviter_id}>' if inviter_id else 'Unknown'),
            invites=invite_uses,
        )
        draw.text((500, 270), text[:120], anchor="mm", font=font, fill="white")
        return im

    def _render_sync(self, member, background_bytes, template, count, avatar, inviter_id=None, invite_uses=0):
        if background_bytes:
            source = Image.open(BytesIO(background_bytes))
        else:
            source = Image.new("RGBA", (1000, 350), (32, 36, 43, 255))

        frames = []
        durations = []
        try:
            frame_count = getattr(source, "n_frames", 1)
            for index in range(frame_count):
                source.seek(index)
                frame = self._frame(source.copy(), member, template, count, avatar, inviter_id, invite_uses)
                frames.append(frame)
                durations.append(source.info.get("duration", 100))
        except EOFError:
            pass
        finally:
            source.close()

        if not frames:
            frames = [self._frame(Image.new("RGBA", (1000, 350), (32, 36, 43, 255)), member, template, count, avatar, inviter_id, invite_uses)]
            durations = [100]

        out = BytesIO()
        if len(frames) == 1:
            frames[0].save(out, format="GIF", save_all=True, loop=0)
        else:
            frames[0].save(
                out,
                format="GIF",
                save_all=True,
                append_images=frames[1:],
                duration=durations,
                loop=0,
                disposal=2,
                optimize=False,
            )
        out.seek(0)
        return out
