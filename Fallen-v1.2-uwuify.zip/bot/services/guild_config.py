from sqlalchemy import select
from bot.models import GuildConfig
from bot.cache.keys import guild as guild_key
from bot.cache.singleflight import DistributedSingleFlight

class GuildConfigService:
    def __init__(self, db, cache, ttl=600, lock_ttl_ms=30000):
        self.db, self.cache, self.ttl = db, cache, ttl
        self.singleflight = DistributedSingleFlight(cache, lock_ttl_ms)

    def _default(self, gid):
        return {'guild_id':gid,'welcome_channel_id':None,'goodbye_channel_id':None,'log_channel_id':None,'autorole_id':None,'welcome_message':'Welcome {mention} to {server}! You are member #{count}.','goodbye_message':'Goodbye {name}!','welcome_background':'assets/welcome.gif','goodbye_background':'assets/goodbye.gif','welcome_embed_enabled':True,'goodbye_embed_enabled':True,'welcome_embed_title':'Welcome!','goodbye_embed_title':'Goodbye!','welcome_embed_description':'{mention} just joined {server}! 🎉','goodbye_embed_description':'{name} has left {server}. 👋','welcome_embed_color':5793266,'goodbye_embed_color':9807270,'automod_enabled':False,'spam_limit':6,'spam_window':8}

    async def get(self, gid):
        key = guild_key(gid)
        async def read():
            return await self.cache.get_json(key)
        async def load():
            async with self.db.session() as s:
                result = await s.execute(select(*GuildConfig.__table__.c).where(GuildConfig.guild_id == gid))
                row = result.mappings().first()
                return dict(row) if row else self._default(gid)
        return await self.singleflight.run(key, load, read)

    async def invalidate(self, gid):
        key = guild_key(gid)
        await self.cache.delete(key)
        # Pub/Sub is only a latency optimization; the cache TTL remains the
        # correctness fallback if a subscriber is disconnected.
        await self.cache.publish('guild-config-invalidated', {'guild_id': gid})
