from __future__ import annotations
import asyncio
import logging
import time
from typing import Optional
import aiohttp

log = logging.getLogger('bot.reactions')

class ReactionGifService:
    """Fast reaction GIF resolver with TTL caching and per-action coalescing."""
    BASE = 'https://nekos.best/api/v2/'
    ALIASES = {
        'highfive': 'highfive', 'pat': 'pat', 'bonk': 'bonk', 'poke': 'poke',
        'hug': 'hug',
        'wave': 'wave', 'dance': 'dance', 'smile': 'smile', 'happy': 'happy',
        'cry': 'cry', 'sleep': 'sleep', 'shrug': 'shrug', 'boop': 'boop',
        'punch': 'punch', 'slap': 'slap', 'bite': 'bite', 'tickle': 'tickle',
        'hold': 'hold', 'pout': 'pout', 'blush': 'blush', 'uwu': 'happy',
    }
    def __init__(self):
        self._session: Optional[aiohttp.ClientSession] = None
        self._locks: dict[str, asyncio.Lock] = {}
        self._cache: dict[str, tuple[float, Optional[str]]] = {}
        self._inflight: dict[str, asyncio.Task] = {}
        self._cache_ttl = 900.0
        self._failure_ttl = 8.0
        self._max_cache = 256

    async def start(self):
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=3.0))

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()
        self._cache.clear()
        self._locks.clear()

    async def get(self, action: str) -> Optional[str]:
        action = self.ALIASES.get(action, action)
        now = time.monotonic()
        cached = self._cache.get(action)
        if cached and now - cached[0] < (self._cache_ttl if cached[1] else 15.0):
            return cached[1]
        lock = self._locks.setdefault(action, asyncio.Lock())
        async with lock:
            now = time.monotonic()
            cached = self._cache.get(action)
            if cached and now - cached[0] < (self._cache_ttl if cached[1] else self._failure_ttl):
                return cached[1]
            await self.start()
            url: Optional[str] = None
            try:
                async with self._session.get(f'{self.BASE}{action}') as r:
                    if r.status == 200:
                        data = await r.json()
                        url = data.get('results', [{}])[0].get('url')
            except (aiohttp.ClientError, asyncio.TimeoutError, ValueError):
                log.warning('reaction GIF provider unavailable action=%s', action)
            # Positive results stay hot; failures expire quickly so recovery is fast.
            self._cache[action] = (time.monotonic(), url)
            if len(self._cache) > self._max_cache:
                oldest = min(self._cache, key=lambda k: self._cache[k][0])
                self._cache.pop(oldest, None)
            return url
