import discord
from discord import app_commands
from discord.ext import commands
from sqlalchemy import text
class Admin(commands.Cog):
    def __init__(self,bot):self.bot=bot
    group=app_commands.Group(name='config',description='Configure the server')
    @group.command(name='autorole')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def autorole(self,i,role:discord.Role|None):
        async with self.bot.db.session() as s:
            await s.execute(text('INSERT INTO guild_configs(guild_id,autorole_id) VALUES (:g,:r) ON CONFLICT(guild_id) DO UPDATE SET autorole_id=EXCLUDED.autorole_id'),{'g':i.guild_id,'r':role.id if role else None});await s.commit()
        await self.bot.guild_config.invalidate(i.guild_id);await i.response.send_message(f'Autorole: {role.mention if role else "disabled"}.')
    @group.command(name='logs')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def logs(self,i,channel:discord.TextChannel|None):
        async with self.bot.db.session() as s:
            await s.execute(text('INSERT INTO guild_configs(guild_id,log_channel_id) VALUES (:g,:c) ON CONFLICT(guild_id) DO UPDATE SET log_channel_id=EXCLUDED.log_channel_id'),{'g':i.guild_id,'c':channel.id if channel else None});await s.commit()
        await self.bot.guild_config.invalidate(i.guild_id);await i.response.send_message(f'Log channel: {channel.mention if channel else "disabled"}.')
    @group.command(name='automod')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def automod(self,i,enabled:bool,spam_limit:app_commands.Range[int,3,20]=6,window:app_commands.Range[int,2,60]=8):
        async with self.bot.db.session() as s:
            await s.execute(text('INSERT INTO guild_configs(guild_id,automod_enabled,spam_limit,spam_window) VALUES (:g,:e,:l,:w) ON CONFLICT(guild_id) DO UPDATE SET automod_enabled=EXCLUDED.automod_enabled,spam_limit=EXCLUDED.spam_limit,spam_window=EXCLUDED.spam_window'),{'g':i.guild_id,'e':enabled,'l':spam_limit,'w':window});await s.commit()
        await self.bot.guild_config.invalidate(i.guild_id);await i.response.send_message(f'AutoMod **{"enabled" if enabled else "disabled"}** — {spam_limit} messages/{window}s.')
async def setup(bot):await bot.add_cog(Admin(bot))
