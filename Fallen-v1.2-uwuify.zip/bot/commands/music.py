from discord.ext import commands
from discord import app_commands
class Music(commands.Cog):
    """Lavalink boundary. The gateway process never runs FFmpeg."""
    def __init__(self,bot):self.bot=bot
    @app_commands.command(name='music-status',description='Show external music node status')
    async def status(self,i):await i.response.send_message('🎵 Music engine: external-node adapter. Configure LAVALINK_URL to enable playback.')
async def setup(bot):await bot.add_cog(Music(bot))
